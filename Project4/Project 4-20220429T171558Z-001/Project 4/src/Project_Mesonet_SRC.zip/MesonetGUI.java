
public class MesonetGUI{

public static void main(String[] args) {
        new MesonetFrame("Oklahoma Mesonet Calculator");
    }    
}
    

