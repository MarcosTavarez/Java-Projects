
public abstract class AbstractObservation
{

    protected boolean valid;

    public AbstractObservation()
    {
        // Does not need to do anything
    }

    public abstract boolean isValid();

}
