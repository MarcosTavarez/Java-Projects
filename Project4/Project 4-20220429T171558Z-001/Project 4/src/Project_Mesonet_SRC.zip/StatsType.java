
public enum StatsType
{
    AVERAGE, MAXIMUM, MINIMUM, TOTAL

}
